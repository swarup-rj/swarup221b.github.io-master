# Style Guideline for programming with R Programming Language

The coding practice follows the Google's R Style Guide at: https://google.github.io/styleguide/Rguide.xml

Exception: single hash is used to comment codes and double hashes are used to comment plain english sentences.
